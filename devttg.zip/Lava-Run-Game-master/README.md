<Strong> Lava Run Game </Strong>

An Obligatory free running game made using Phaser Framework as a part of my College Project. 
This is officially my first game made using Phaser. It was a great learning experience to work on phaser because i got to learn Javascript.
<br>
<strong>Can play it on any browser which support JavaScript and canvas tags ofcourse. Click on the<a href="https://sidf3ar.github.io/Lava-Run-Game/"> Play it Now..!</a> to checkout the game.</strong>
<br>
<br>
<strong>## ScreenShot</strong>
<br>
<a href="https://ibb.co/gixVh7"><img src="https://preview.ibb.co/eANwN7/lava_1.png" height="500" width="300" alt="lava_1" border="0"></a>

<Strong>## Android App</Strong>
I ported this Web App to a Native Android App using Apache Cordova Framework.
<strong>Link to Lava Run's android APK https://drive.google.com/open?id=1_gNE678PsK6_ijk2AeoHx87DJJNr1Tgt</strong>

<Strong>## Prerequisites<br>
HTML, CSS, JavaScript and knowledge about Phaser Framework.</strong>


<Strong>## Credits</Strong>
This game was made using my own genuine assets and generated music by Oyvind Torvund. 

Feel free to fork this game, use code and assets. Just do not be evil. :smile:
